<?php
ob_start();
include("autoload.php");

$util = new Utils();
$records=$util->listGalleryImages(1);
echo json_encode($records);
?>