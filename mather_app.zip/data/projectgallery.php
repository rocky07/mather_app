<?php
echo "[{html:'images/1.jpg',xtype:'panel'},{html:'images/2.jpg',xtype:'panel'},{html:'images/3.jpg',xtype:'panel'},{html:'images/4.jpg',xtype:'panel'},{html:'images/5.jpg',xtype:'panel'}]";
?>
