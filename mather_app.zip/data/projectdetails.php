<?php
echo "{id:1,name:'Plum flower',loc:'axxs',imgIcon:'images/veneziano1.jpg',
gallery:[{key:'images/test.jpg'},{key:'images/test.jpg'},{key:'images/test.jpg'}],
amenities:[{key:'val 1'},{key:'val 2'}],
specification:[{key:'val 1'},{key:'val 2'}],
status:'status',description:'Project Type: lifestyle villas <br/>Project Status: New Project Veneziano is a fine example of Mather’s unique approach to living. Through the heart of the project, runs a canal that pays tribute to the waterways of venice. Using greenery and water,Veneziano recreates the magic ambience of Venice, but fuses it with a completely contemporary look to make it truly, the newest in living'}";
